from melodramatick.work.views import WorkDetailView, WorkTableView

from .filters import BalletFilter
from .models import Ballet
from .tables import BalletTable


class BalletDetailView(WorkDetailView):
    model = Ballet


class BalletTableView(WorkTableView):
    model = Ballet
    table_class = BalletTable
    filterset_class = BalletFilter
