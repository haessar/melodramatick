from melodramatick.settings import *  # noqa: F401, F403
from melodramatick.settings import INSTALLED_APPS as IMPORTED_APPS
from melodramatick.settings import BASE_DIR, ALLOWED_HOSTS, TEMPLATES, STATICFILES_DIRS


ALLOWED_HOSTS.extend(["127.0.0.1", "concertantick", "concertantick.com", "www.concertantick.com",
                      "concertantick.melodramatick.com"])


#  Application definition

INSTALLED_APPS = ['concertantick'] + IMPORTED_APPS

TEMPLATES[0]['DIRS'].extend([BASE_DIR / "concertantick" / "templates"])

STATIC_ROOT = '/var/www/concertantick/static'
STATICFILES_DIRS = [BASE_DIR / "concertantick" / "static"] + STATICFILES_DIRS


# Site-specific settings

WORK_MODEL = 'concertantick.Concerto'
WORK_PLURAL_LABEL = 'concertos'

SITE = 'Concertantick'
BACKGROUND_COLOUR = '#eee80e'

SITE_ID = 3

INSTRUMENT_CHOICES = [
    ("accordion", "Accordion"),
    ("bassoon", "Bassoon"),
    ("cello", "Cello"),
    ("clarinet", "Clarinet"),
    ("cor_anglais", "Cor anglais"),
    ("double_bass", "Double Bass"),
    ("flute", "Flute"),
    ("french_horn", "French Horn"),
    ("guitar", "Guitar"),
    ("harp", "Harp"),
    ("harpsichord", "Harpsichord"),
    ("mandolin", "Mandolin"),
    ("oboe", "Oboe"),
    ("orchestra", "Orchestra"),
    ("organ", "Organ"),
    ("percussion", "Percussion"),
    ("piano", "Piano"),
    ("saxophone", "Saxophone"),
    ("trombone", "Trombone"),
    ("trumpet", "Trumpet"),
    ("viola", "Viola"),
    ("violin", "Violin"),
]

VERBOSE_TITLE = True
