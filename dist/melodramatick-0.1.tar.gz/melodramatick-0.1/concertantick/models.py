from django.conf import settings
from django.db import models

from melodramatick.work.models import Work


class Concerto(Work):
    instrument = models.CharField(choices=settings.INSTRUMENT_CHOICES, max_length=12, blank=True)

    @property
    def instrument_verbose(self):
        return [v for (c, v) in settings.INSTRUMENT_CHOICES if c == self.instrument][0]
